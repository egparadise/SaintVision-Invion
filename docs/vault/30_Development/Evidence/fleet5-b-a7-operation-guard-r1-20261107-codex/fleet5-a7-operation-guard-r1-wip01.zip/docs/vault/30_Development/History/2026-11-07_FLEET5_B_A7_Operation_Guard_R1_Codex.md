---
doc_id: "HISTORY-FLEET5-B-A7-OPERATION-GUARD-R1-CODEX-20261107"
title: "FLEET5 B A7 operation guard R1 WIP freeze"
version: "1.0.0"
status: "review"
author: "Codex"
updated: "2026-11-07T09:24:00+09:00"
source_of_truth: "Git WIP; Root isolated verification pending"
---

Root message `msg_db48b2c9a36e` activates finite card
`FLEET5-B-A7-OPERATION-GUARD-R1-20261107`, under Orca task
`task_a8fd2969f0b3` / dispatch `ctx_6f0f8253b8a7`. Owner is Codex;
actual independent operation guard reviewer is PENDING through Root. Branch is
`agent/codex/fleet5-b-a7-operation-guard-r1-20261107`, exact base
`b3bbdc8d92a39f2f797a7680deb2770d6f705af0`. This stage has no new commit,
push, CI, actual product import or pytest execution. It is not locally verified,
integrated, operationally accepted, or task complete.

Latest canonical first-read records are in own Evidence `inputs.json`: Root Git
`c23ae5d19773f627b796f860200ba6e6079d62e7`, Index `1.0.493`, Codex board
`1.0.454` (09:13:21 KST). It records exact doc IDs, versions, hashes, KST,
AGENTS, agent-delivery `1.1.0`, core-reliability `1.0.0`, and registry hash.
Unchanged canonical plans retain their prior reads. No shared board, ADR,
registry, source original, or Obsidian file was edited.

Actual preceding independent review is Claude
`e75b051d8dcd39b24dba4b648d74d7f7adecbd0f`, direct parent b3bb;
13 original review files are copied byte-for-byte with Git object IDs and hashes.
Its Docs run `42315871269` / job `128228196870`, attempt 1, was reported by Root
as all 19 successful. That preceding verdict conditionally accepts source
evidence and keeps all 19 HOLD; A7M-L1 carries forward. It is not a review of
this product WIP.

The only non-doc changes are `DeliveryWorker.once` in
`services/control-plane/src/inv/dispatch.py` and the new
`tests/core/test_delivery_operation_origin.py`. Inside the existing try, the
worker captures `attempt.operation` once and requires exact builtin `str` in
the three-value domain before the existing deliver call compares that local.
The existing exception handler, finish call, not_sent behavior, callback order,
NodeDelivery defaults and truthiness/or expressions remain byte/AST compatible
outside the granted edit. The reverse exact patch restores the complete BASE
module AST. Earlier reconciliation and acquire effects have already happened;
property capture itself and genuine type/str/receiver bindings remain premises.

The new unit file imports actual `inv.dispatch`, calls actual
`DeliveryWorker.once`, and replaces minimal collaborators with spies. Its 24
planned cases cover three genuine literals and exact builtin bool pairs, 14
invalid origins including hostile rich methods and string subclasses, a raising
capture property, None/control-only branches, and stopped followup ordering.
This count is static, not a pytest collection or execution receipt. The finish
spy does not emulate real queue SQL, and the actual finish method's distinct
short-circuited `attempt.operation` read remains unchanged and untested here.

At 09:21:00–09:21:54 KST the finite static command
`python -B docs/vault/30_Development/Evidence/fleet5-b-a7-operation-guard-r1-20261107-codex/static_checks.py`
exited **0** on Windows / existing Python 3.14.7. It used AST/source/hash/static
DATA only, without executing product, test, or mutant modules. The real b3bb
Git source world contains 25 parsed and 25 audited first-party paths, with only
current dispatch overlaid; nine constructors and one deliver reference are
recorded. Nine controls have their expected results, with no accepted discharge.

C1 now projects the actual forwarding `Call.func` to its `Attribute` in the same
AST, binding node kind, direct parent identity, current path, function, file hash,
span, and expression hash. It does not compare the Attribute span/hash to the
enclosing Call span/hash. Current Attribute is `[339,12,339,33]`, Call is
`[339,12,344,13]`. Whole-scope second/noncall/unconstrained reference controls
reject with **DELIVER_REFERENCE_SET_CHANGED**. The exact review second-caller
fixture retains SHA256
`abb17b22020e6c93820ac9543e1a54a9813d746dcd8dd4851b9543fd0ef93a5e`;
its caller guard is clean, the direct mode/constructor conditions hold, and its
earlier guard refusal set equals actual WIP. That set is not globally clean.

The genuine new product pattern is refused by the unchanged historical guard:
**DYNAMIC_BLOCK:USE_SITE_NOT_ALLOWLISTED:INSTANCE:operation**. First site is the
new Name Store `operation`, dispatch `[336,12,336,21]`, context
`operation = attempt.operation`, frozen multiplicity 0. The diagnostic command
`python -B docs/vault/30_Development/Evidence/fleet5-b-a7-operation-guard-r1-20261107-codex/inspect_refusal.py`
exited **0** at 09:23:26 KST and preserves its exact key and current source
witness. No old helper, guard, allowlist, fallback, or proof credit was changed.
The whole candidate is **UNRESOLVED_OPERATION_ORIGIN** with reason
**EXISTING_GUARD_REFUSED_WIP_PATTERN**, regardless of the new direct predicate's
conditional result. Root's required decision cannot be inferred by the author.

C2 actual-import GREEN and real BASE RED are **NOT_RUN locally**. Root's bounded
isolation plan and exact selectors are in `root-run-plan.json`. The causal RED
case uses the actual b3bb dispatch module with the new unit file, after fixture
preconditions: foreign-equal reaches the actual old delivery call and should
fail the intended `case.deliveries == []` assertion. Neither product code nor an
extracted/copied implementation is executed to claim RED here. Root must verify
the intended failure, not merely accept a nonzero import/collection error.

The immutable WIP01 ZIP contains safe relative paths, exact entry hashes/bytes,
complete product/test diff, current source world and new own proof. Its outer
receipt binds every entry and the ZIP SHA256/bytes; re-freezing refuses to
overwrite. Root reconstructs real base/test/conftest/import closure and pinned
dependency files, then overlays only the two permitted non-doc files. No stubs
replace the actual product implementation. No publication or mutable test result
is inserted into this packet after freezing.

Next action/owner: Root verifies WIP01 and returns bounded actual-import GREEN
and causal BASE RED receipts, and chooses an explicit narrow proof-compatibility
contract for the exact captured operation pattern or keeps this WIP held. Codex
must not alter the older guard or add an allowance before that decision. A new
Root step is required before publication; actual independent review remains
pending. Global baseline 19 HOLD, runtime B=0, real bindings NULL, A1–A16 pending,
12 entries / 19 edges / 16+3 split and six accounting figures
598/757/1071/21/573/218 remain unchanged. Whole B and the five-PC program are
incomplete.
